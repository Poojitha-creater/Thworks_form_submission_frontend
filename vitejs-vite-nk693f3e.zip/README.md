# Frontend - Form Submission App

This is the *frontend* part of the project built using *React (Vite)*.  
It provides a simple form where users can enter their *name, email, and phone number*.  
When submitted, the form sends data to the backend API using *Axios*.

---

### 🚀 Features
- Simple and clean UI for user input
- Data validation using HTML5 form attributes
- Sends form data to backend using axios.post()
- Shows success or error message after submission

---

### 🛠 Tech Stack
- React (Vite)
- Axios
- HTML, CSS, JavaScript

---

### ⚙ Setup & Run

1. Install dependencies  
   ```bash
   npm install

2. Start the frontend server 
    npm run dev 

3. The app runs on 
   https://localhost:5173 

4.Make sure your backend server is running on port 5000